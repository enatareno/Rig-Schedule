import { Timestamp } from "firebase/firestore";

export type JobStatus = "Planned" | "Active" | "Standby" | "Complete" | "Cancelled";

export type Job = {
  id: string;
  rigId: string;
  rigName: string;

  jobName: string;
  contractor: string;
  engineer: string;

  workOrder: string;
  scope: string;
  processToComplete: string;

  startDate: Timestamp;
  endDate: Timestamp;

  status: JobStatus;

  duration: number;   // planned days
  daysOnJob: number;  // actual days

  waterSamples: number | null;
  testHoleDepth: number | null;

  notes: string;

  locationText: string;
  locationLink: string;

  lat: number | null;
  lng: number | null;

  createdAt: Timestamp;
  updatedAt: Timestamp;
};

export type JobDraft = Omit<Job, "id" | "createdAt" | "updatedAt">;

export type Filters = {
  rigs: string[]; // rigIds
  statuses: JobStatus[];
  contractor: string;
  engineer: string;
  search: string;
  from?: Date;
  to?: Date;
};
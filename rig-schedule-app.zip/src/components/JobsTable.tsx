import React from "react";
import { Job } from "../types";

function formatDate(ms: number): string {
  const d = new Date(ms);
  return d.toISOString().slice(0, 10);
}

function statusClass(s: string) {
  const k = s.toLowerCase();
  if (k === "active") return "active";
  if (k === "planned") return "planned";
  if (k === "standby") return "standby";
  if (k === "complete") return "complete";
  if (k === "cancelled") return "cancelled";
  return "";
}

export default function JobsTable({
  jobs,
  conflicts,
  onOpen
}: {
  jobs: Job[];
  conflicts: Set<string>;
  onOpen: (job: Job) => void;
}) {
  return (
    <div className="card">
      <div className="tableWrap">
        <table>
          <thead>
            <tr>
              <th>Rig</th>
              <th>Job</th>
              <th>Contractor</th>
              <th>Engineer</th>
              <th>WO</th>
              <th>Start</th>
              <th>End</th>
              <th>Dur</th>
              <th>Days</th>
              <th>Status</th>
              <th>Scope</th>
              <th>Water</th>
              <th>Test Hole</th>
              <th>Location</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            {jobs.map(j => {
              const isConflict = conflicts.has(j.id);
              return (
                <tr key={j.id} onClick={() => onOpen(j)} style={{ cursor: "pointer" }}>
                  <td>
                    <div>{j.rigName}</div>
                    {isConflict && <div className="small" style={{ color: "var(--bad)" }}>⚠ conflict</div>}
                  </td>
                  <td>{j.jobName}</td>
                  <td>{j.contractor}</td>
                  <td>{j.engineer}</td>
                  <td>{j.workOrder}</td>
                  <td>{j.startDate ? formatDate(j.startDate.toMillis()) : ""}</td>
                  <td>{j.endDate ? formatDate(j.endDate.toMillis()) : ""}</td>
                  <td>{j.duration || ""}</td>
                  <td>{j.daysOnJob || ""}</td>
                  <td><span className={"badge " + statusClass(j.status)}>{j.status}</span></td>
                  <td>{j.scope}</td>
                  <td>{j.waterSamples ?? ""}</td>
                  <td>{j.testHoleDepth ?? ""}</td>
                  <td>
                    {j.locationLink ? (
                      <a href={j.locationLink} target="_blank" rel="noreferrer">Map link</a>
                    ) : (
                      j.locationText
                    )}
                  </td>
                  <td className="small">{j.notes}</td>
                </tr>
              );
            })}
            {jobs.length === 0 && (
              <tr>
                <td colSpan={15} className="small">No jobs match your filters.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="small" style={{ marginTop: 10 }}>
        Click any row to edit.
      </div>
    </div>
  );
}
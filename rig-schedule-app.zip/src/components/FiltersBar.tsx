import React, { useMemo } from "react";
import { Filters, Job, JobStatus } from "../types";

const STATUSES: JobStatus[] = ["Planned", "Active", "Standby", "Complete", "Cancelled"];

function uniq(arr: string[]): string[] {
  return Array.from(new Set(arr)).sort((a,b) => a.localeCompare(b));
}

export default function FiltersBar({
  jobs,
  filters,
  setFilters
}: {
  jobs: Job[];
  filters: Filters;
  setFilters: (f: Filters) => void;
}) {
  const rigs = useMemo(() => uniq(jobs.map(j => j.rigId)), [jobs]);
  const contractors = useMemo(() => uniq(jobs.map(j => j.contractor).filter(Boolean)), [jobs]);
  const engineers = useMemo(() => uniq(jobs.map(j => j.engineer).filter(Boolean)), [jobs]);

  return (
    <div className="card" style={{ marginBottom: 12 }}>
      <div className="row">
        <div style={{ minWidth: 200 }}>
          <div className="label">Rig (multi-select)</div>
          <select
            multiple
            value={filters.rigs}
            onChange={(e) => {
              const values = Array.from(e.target.selectedOptions).map(o => o.value);
              setFilters({ ...filters, rigs: values });
            }}
            style={{ width: "100%", height: 110 }}
          >
            {rigs.map(r => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
          <div className="small">Tip: Ctrl/Command + click to select multiple</div>
        </div>

        <div style={{ minWidth: 180 }}>
          <div className="label">Status</div>
          <select
            multiple
            value={filters.statuses}
            onChange={(e) => {
              const values = Array.from(e.target.selectedOptions).map(o => o.value as JobStatus);
              setFilters({ ...filters, statuses: values });
            }}
            style={{ width: "100%", height: 110 }}
          >
            {STATUSES.map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>

        <div style={{ minWidth: 220 }}>
          <div className="label">Contractor</div>
          <select
            value={filters.contractor}
            onChange={(e) => setFilters({ ...filters, contractor: e.target.value })}
            style={{ width: "100%" }}
          >
            <option value="">All</option>
            {contractors.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>

        <div style={{ minWidth: 220 }}>
          <div className="label">Engineer</div>
          <select
            value={filters.engineer}
            onChange={(e) => setFilters({ ...filters, engineer: e.target.value })}
            style={{ width: "100%" }}
          >
            <option value="">All</option>
            {engineers.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>

        <div style={{ minWidth: 180 }}>
          <div className="label">From</div>
          <input
            type="date"
            value={filters.from ? filters.from.toISOString().slice(0,10) : ""}
            onChange={(e) => setFilters({ ...filters, from: e.target.value ? new Date(e.target.value) : undefined })}
            style={{ width: "100%" }}
          />
        </div>

        <div style={{ minWidth: 180 }}>
          <div className="label">To</div>
          <input
            type="date"
            value={filters.to ? filters.to.toISOString().slice(0,10) : ""}
            onChange={(e) => setFilters({ ...filters, to: e.target.value ? new Date(e.target.value) : undefined })}
            style={{ width: "100%" }}
          />
        </div>

        <div style={{ flex: 1, minWidth: 220 }}>
          <div className="label">Search (job / WO / notes)</div>
          <input
            placeholder="Search…"
            value={filters.search}
            onChange={(e) => setFilters({ ...filters, search: e.target.value })}
            style={{ width: "100%" }}
          />
        </div>

        <div>
          <button
            className="danger"
            onClick={() => setFilters({ rigs: [], statuses: [], contractor: "", engineer: "", search: "" })}
          >
            Clear
          </button>
        </div>
      </div>
    </div>
  );
}
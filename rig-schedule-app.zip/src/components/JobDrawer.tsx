import React, { useEffect, useMemo, useState } from "react";
import { Job, JobStatus } from "../types";
import { doc, updateDoc, Timestamp } from "firebase/firestore";
import { db } from "../firebase";

const STATUSES: JobStatus[] = ["Planned", "Active", "Standby", "Complete", "Cancelled"];

function toISO(ms: number) { return new Date(ms).toISOString().slice(0,10); }

export default function JobDrawer({
  job,
  onClose
}: {
  job: Job | null;
  onClose: () => void;
}) {
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const [form, setForm] = useState({
    rigName: "",
    jobName: "",
    contractor: "",
    engineer: "",
    workOrder: "",
    status: "Planned" as JobStatus,
    scope: "",
    processToComplete: "",
    startDate: "",
    endDate: "",
    duration: 0,
    daysOnJob: 0,
    waterSamples: "",
    testHoleDepth: "",
    notes: "",
    locationText: "",
    locationLink: ""
  });

  useEffect(() => {
    if (!job) return;
    setErr("");
    setForm({
      rigName: job.rigName || "",
      jobName: job.jobName || "",
      contractor: job.contractor || "",
      engineer: job.engineer || "",
      workOrder: job.workOrder || "",
      status: job.status || "Planned",
      scope: job.scope || "",
      processToComplete: job.processToComplete || "",
      startDate: job.startDate ? toISO(job.startDate.toMillis()) : "",
      endDate: job.endDate ? toISO(job.endDate.toMillis()) : "",
      duration: job.duration || 0,
      daysOnJob: job.daysOnJob || 0,
      waterSamples: job.waterSamples === null ? "" : String(job.waterSamples),
      testHoleDepth: job.testHoleDepth === null ? "" : String(job.testHoleDepth),
      notes: job.notes || "",
      locationText: job.locationText || "",
      locationLink: job.locationLink || ""
    });
  }, [job]);

  const canSave = useMemo(() => !!job && !!form.jobName && !!form.rigName, [job, form]);

  async function save() {
    if (!job) return;
    setSaving(true);
    setErr("");
    try {
      const ref = doc(db, "jobs", job.id);

      const start = form.startDate ? Timestamp.fromDate(new Date(form.startDate)) : job.startDate;
      const end = form.endDate ? Timestamp.fromDate(new Date(form.endDate)) : job.endDate;

      const duration = Number(form.duration) || 0;
      const daysOnJob = Number(form.daysOnJob) || 0;
      const waterSamples = form.waterSamples === "" ? null : Number(form.waterSamples);
      const testHoleDepth = form.testHoleDepth === "" ? null : Number(form.testHoleDepth);

      await updateDoc(ref, {
        rigName: form.rigName.trim(),
        jobName: form.jobName.trim(),
        contractor: form.contractor.trim(),
        engineer: form.engineer.trim(),
        workOrder: form.workOrder.trim(),
        status: form.status,
        scope: form.scope.trim(),
        processToComplete: form.processToComplete.trim(),
        startDate: start,
        endDate: end,
        duration,
        daysOnJob,
        waterSamples: Number.isFinite(waterSamples as any) ? waterSamples : null,
        testHoleDepth: Number.isFinite(testHoleDepth as any) ? testHoleDepth : null,
        notes: form.notes.trim(),
        locationText: form.locationText.trim(),
        locationLink: form.locationLink.trim(),
        updatedAt: Timestamp.now()
      });

      onClose();
    } catch (e: any) {
      setErr(e?.message || "Failed to save changes.");
    } finally {
      setSaving(false);
    }
  }

  if (!job) return null;

  return (
    <div className="drawerOverlay" onMouseDown={onClose}>
      <div className="drawer" onMouseDown={(e) => e.stopPropagation()}>
        <div className="drawerHeader">
          <div>
            <div className="drawerTitle">Edit Job</div>
            <div className="small">{job.rigName} • {job.jobName}</div>
          </div>
          <button onClick={onClose}>Close</button>
        </div>

        <div className="hr" />

        {err && <div className="warning" style={{ marginBottom: 12 }}>{err}</div>}

        <div className="row">
          <div style={{ flex: 1, minWidth: 220 }}>
            <div className="label">Rig</div>
            <input value={form.rigName} onChange={(e) => setForm({ ...form, rigName: e.target.value })} style={{ width: "100%" }} />
          </div>
          <div style={{ flex: 2, minWidth: 260 }}>
            <div className="label">Job</div>
            <input value={form.jobName} onChange={(e) => setForm({ ...form, jobName: e.target.value })} style={{ width: "100%" }} />
          </div>
        </div>

        <div className="row" style={{ marginTop: 10 }}>
          <div style={{ flex: 1, minWidth: 220 }}>
            <div className="label">Contractor</div>
            <input value={form.contractor} onChange={(e) => setForm({ ...form, contractor: e.target.value })} style={{ width: "100%" }} />
          </div>
          <div style={{ flex: 1, minWidth: 220 }}>
            <div className="label">Engineer</div>
            <input value={form.engineer} onChange={(e) => setForm({ ...form, engineer: e.target.value })} style={{ width: "100%" }} />
          </div>
        </div>

        <div className="row" style={{ marginTop: 10 }}>
          <div style={{ flex: 1, minWidth: 170 }}>
            <div className="label">Work Order</div>
            <input value={form.workOrder} onChange={(e) => setForm({ ...form, workOrder: e.target.value })} style={{ width: "100%" }} />
          </div>
          <div style={{ flex: 1, minWidth: 170 }}>
            <div className="label">Status</div>
            <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as JobStatus })} style={{ width: "100%" }}>
              {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="row" style={{ marginTop: 10 }}>
          <div style={{ flex: 1, minWidth: 180 }}>
            <div className="label">Start Date</div>
            <input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} style={{ width: "100%" }} />
          </div>
          <div style={{ flex: 1, minWidth: 180 }}>
            <div className="label">End Date</div>
            <input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} style={{ width: "100%" }} />
          </div>
        </div>

        <div className="row" style={{ marginTop: 10 }}>
          <div style={{ flex: 1, minWidth: 170 }}>
            <div className="label">Duration (days)</div>
            <input type="number" value={form.duration} onChange={(e) => setForm({ ...form, duration: Number(e.target.value) })} style={{ width: "100%" }} />
          </div>
          <div style={{ flex: 1, minWidth: 170 }}>
            <div className="label">Days on Job</div>
            <input type="number" value={form.daysOnJob} onChange={(e) => setForm({ ...form, daysOnJob: Number(e.target.value) })} style={{ width: "100%" }} />
          </div>
        </div>

        <div className="row" style={{ marginTop: 10 }}>
          <div style={{ flex: 1, minWidth: 220 }}>
            <div className="label">Scope</div>
            <input value={form.scope} onChange={(e) => setForm({ ...form, scope: e.target.value })} style={{ width: "100%" }} />
          </div>
          <div style={{ flex: 1, minWidth: 220 }}>
            <div className="label">Process to Complete</div>
            <input value={form.processToComplete} onChange={(e) => setForm({ ...form, processToComplete: e.target.value })} style={{ width: "100%" }} />
          </div>
        </div>

        <div className="row" style={{ marginTop: 10 }}>
          <div style={{ flex: 1, minWidth: 170 }}>
            <div className="label">Water Samples</div>
            <input type="number" value={form.waterSamples} onChange={(e) => setForm({ ...form, waterSamples: e.target.value })} style={{ width: "100%" }} />
          </div>
          <div style={{ flex: 1, minWidth: 170 }}>
            <div className="label">Test Hole Depth</div>
            <input type="number" value={form.testHoleDepth} onChange={(e) => setForm({ ...form, testHoleDepth: e.target.value })} style={{ width: "100%" }} />
          </div>
        </div>

        <div className="row" style={{ marginTop: 10 }}>
          <div style={{ flex: 1, minWidth: 220 }}>
            <div className="label">Location text</div>
            <input value={form.locationText} onChange={(e) => setForm({ ...form, locationText: e.target.value })} style={{ width: "100%" }} />
          </div>
          <div style={{ flex: 1, minWidth: 220 }}>
            <div className="label">Location link (optional)</div>
            <input value={form.locationLink} onChange={(e) => setForm({ ...form, locationLink: e.target.value })} style={{ width: "100%" }} />
          </div>
        </div>

        <div style={{ marginTop: 10 }}>
          <div className="label">Notes</div>
          <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} style={{ width: "100%", minHeight: 90 }} />
        </div>

        <div className="hr" />

        <div className="row" style={{ justifyContent: "flex-end" }}>
          <button className="primary" onClick={save} disabled={!canSave || saving}>
            {saving ? "Saving…" : "Save Changes"}
          </button>
        </div>

        <div className="small" style={{ marginTop: 10 }}>
          Lat/Long are intentionally blank in this app — fill later when you’re ready for the map.
        </div>
      </div>
    </div>
  );
}
import React from "react";

export type TabKey = "schedule" | "import";

export default function Tabs({ active, onChange }: { active: TabKey; onChange: (t: TabKey) => void; }) {
  return (
    <div className="tabs">
      <button className={"tab " + (active === "schedule" ? "active" : "")} onClick={() => onChange("schedule")}>
        Schedule
      </button>
      <button className={"tab " + (active === "import" ? "active" : "")} onClick={() => onChange("import")}>
        Import Excel
      </button>
    </div>
  );
}
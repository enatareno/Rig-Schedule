import React, { useMemo, useState } from "react";
import * as XLSX from "xlsx";
import { Timestamp, writeBatch, collection, doc } from "firebase/firestore";
import { db } from "../firebase";
import { JobDraft, JobStatus } from "../types";
import { normKey, parseDurationDays, safeNum, safeStr, toRigId, maybeUrl } from "../utils/normalize";

type PreviewRow = {
  ok: boolean;
  errors: string[];
  draft: JobDraft;
};

const DEFAULT_STATUS: JobStatus = "Planned";

const HEADER_SYNONYMS: Record<string, string[]> = {
  rig: ["rig", "rig no", "rig no ", "rig number", "rig #", "rig id"],
  job: ["job", "well", "well name", "job name"],
  contractor: ["contractor", "client", "operator"],
  engineer: ["engineer", "pm", "project manager"],
  startDate: ["start date", "start"],
  endDate: ["end date", "end"],
  status: ["status"],
  duration: ["duration", "duration days"],
  daysOnJob: ["days on job", "days"],
  scope: ["scope"],
  waterSamples: ["water samples", "samples", "water sample"],
  testHoleDepth: ["test hole depth", "testhole depth", "test hole", "test depth"],
  notes: ["notes", "comment", "comments"],
  locationText: ["location text (optional: city/county)", "location text", "location", "site", "city", "county", "location "],
  workOrder: ["work order", "wo"],
  processToComplete: ["process to complete", "process", "process to complete "]
};

function findHeader(map: Record<string, string>, key: keyof typeof HEADER_SYNONYMS): string | null {
  const want = HEADER_SYNONYMS[key];
  for (const candidate of Object.keys(map)) {
    if (want.includes(candidate)) return map[candidate];
  }
  // fuzzy contains
  for (const candidate of Object.keys(map)) {
    if (want.some(w => candidate.includes(w))) return map[candidate];
  }
  return null;
}

function parseDate(v: any): Date | null {
  if (!v) return null;
  if (v instanceof Date && !isNaN(v.getTime())) return v;
  // Excel serial date number
  if (typeof v === "number") {
    const d = XLSX.SSF.parse_date_code(v);
    if (!d) return null;
    return new Date(d.y, d.m - 1, d.d);
  }
  const d = new Date(String(v));
  return isNaN(d.getTime()) ? null : d;
}

export default function ImportExcel() {
  const [fileName, setFileName] = useState("");
  const [preview, setPreview] = useState<PreviewRow[]>([]);
  const [importing, setImporting] = useState(false);
  const [msg, setMsg] = useState("");

  const okCount = useMemo(() => preview.filter(p => p.ok).length, [preview]);
  const badCount = useMemo(() => preview.filter(p => !p.ok).length, [preview]);

  async function onPickFile(file: File) {
    setMsg("");
    setFileName(file.name);
    const ab = await file.arrayBuffer();
    const wb = XLSX.read(ab, { type: "array" });
    // Prefer sheet named "Rig Schedule", else first sheet
    const sheetName = wb.SheetNames.includes("Rig Schedule") ? "Rig Schedule" : wb.SheetNames[0];
    const ws = wb.Sheets[sheetName];

    const rows = XLSX.utils.sheet_to_json(ws, { defval: "" }) as Record<string, any>[];
    if (!rows.length) {
      setPreview([]);
      setMsg("No rows found in the sheet.");
      return;
    }

    // Build normalized header map: normalizedKey -> originalHeader
    const originalHeaders = Object.keys(rows[0] || {});
    const headerMap: Record<string, string> = {};
    for (const h of originalHeaders) headerMap[normKey(h)] = h;

    const rigH = findHeader(headerMap, "rig");
    const jobH = findHeader(headerMap, "job");
    const contractorH = findHeader(headerMap, "contractor");
    const engineerH = findHeader(headerMap, "engineer");
    const startH = findHeader(headerMap, "startDate");
    const endH = findHeader(headerMap, "endDate");
    const statusH = findHeader(headerMap, "status");
    const durationH = findHeader(headerMap, "duration");
    const daysH = findHeader(headerMap, "daysOnJob");
    const scopeH = findHeader(headerMap, "scope");
    const waterH = findHeader(headerMap, "waterSamples");
    const testH = findHeader(headerMap, "testHoleDepth");
    const notesH = findHeader(headerMap, "notes");
    const locH = findHeader(headerMap, "locationText");
    const woH = findHeader(headerMap, "workOrder");
    const processH = findHeader(headerMap, "processToComplete");

    const now = Timestamp.now();

    const parsed: PreviewRow[] = rows
      .map((r) => {
        const errors: string[] = [];

        const rigName = safeStr(rigH ? r[rigH] : "");
        const jobName = safeStr(jobH ? r[jobH] : "");

        // Skip blank rows (common in schedules)
        if (!rigName && !jobName) return null;

        if (!rigName) errors.push("Missing Rig");
        if (!jobName) errors.push("Missing Job");

        const contractor = safeStr(contractorH ? r[contractorH] : "");
        const engineer = safeStr(engineerH ? r[engineerH] : "");

        const start = parseDate(startH ? r[startH] : null);
        const end = parseDate(endH ? r[endH] : null);
        if (!start) errors.push("Bad Start Date");
        if (!end) errors.push("Bad End Date");

        const rawStatus = safeStr(statusH ? r[statusH] : "");
        const status = (rawStatus || DEFAULT_STATUS) as JobStatus;

        const duration = durationH ? parseDurationDays(r[durationH]) : 0;
        const daysOnJob = daysH ? (safeNum(r[daysH]) ?? 0) : 0;

        const scope = safeStr(scopeH ? r[scopeH] : "");
        const processToComplete = safeStr(processH ? r[processH] : "");
        const workOrder = safeStr(woH ? r[woH] : "");

        const waterSamples = waterH ? safeNum(r[waterH]) : null;
        const testHoleDepth = testH ? safeNum(r[testH]) : null;
        const notes = safeStr(notesH ? r[notesH] : "");

        const locRaw = safeStr(locH ? r[locH] : "");
        const loc = maybeUrl(locRaw);

        const draft: JobDraft = {
          rigId: toRigId(rigName),
          rigName,
          jobName,
          contractor,
          engineer,
          workOrder,
          scope,
          processToComplete,

          startDate: start ? Timestamp.fromDate(start) : now,
          endDate: end ? Timestamp.fromDate(end) : now,

          status,

          duration,
          daysOnJob,

          waterSamples,
          testHoleDepth,

          notes,

          locationText: loc.text,
          locationLink: loc.link,

          lat: null,
          lng: null
        };

        return { ok: errors.length === 0, errors, draft };
      })
      .filter(Boolean) as PreviewRow[];

    setPreview(parsed);
    setMsg(`Loaded ${parsed.length} rows from "${sheetName}".`);
  }

  async function importToFirestore() {
    setMsg("");
    setImporting(true);
    try {
      const batch = writeBatch(db);
      const col = collection(db, "jobs");
      const now = Timestamp.now();

      const okRows = preview.filter(p => p.ok);
      if (!okRows.length) {
        setMsg("Nothing to import (no valid rows).");
        return;
      }

      for (const p of okRows) {
        const ref = doc(col); // auto-id
        batch.set(ref, {
          ...p.draft,
          createdAt: now,
          updatedAt: now
        });
      }

      await batch.commit();
      setMsg(`✅ Imported ${okRows.length} jobs into Firestore (collection: jobs).`);
    } catch (e: any) {
      setMsg(`❌ Import failed: ${e?.message || "Unknown error"}`);
    } finally {
      setImporting(false);
    }
  }

  return (
    <div className="card">
      <div className="h1">Import Excel</div>
      <div className="small" style={{ marginTop: 6 }}>
        Upload your rig schedule Excel and import rows into Firestore. Lat/Long will be left blank.
      </div>

      <div className="hr" />

      <div className="row">
        <div style={{ flex: 1 }}>
          <div className="label">Excel File (.xlsx)</div>
          <input
            type="file"
            accept=".xlsx,.xls,.csv"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void onPickFile(f);
            }}
          />
          <div className="small">{fileName ? `Selected: ${fileName}` : ""}</div>
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <button className="primary" disabled={importing || okCount === 0} onClick={() => void importToFirestore()}>
            {importing ? "Importing…" : `Import ${okCount} rows`}
          </button>
        </div>
      </div>

      {msg && <div style={{ marginTop: 12 }} className="small">{msg}</div>}
      {(badCount > 0) && (
        <div className="warning" style={{ marginTop: 12 }}>
          {badCount} row(s) have missing rig/job or invalid dates. Fix them in Excel, then re-upload.
        </div>
      )}

      <div className="hr" />

      <div className="tableWrap">
        <table>
          <thead>
            <tr>
              <th>OK</th>
              <th>Rig</th>
              <th>Job</th>
              <th>Contractor</th>
              <th>Work Order</th>
              <th>Start</th>
              <th>End</th>
              <th>Duration</th>
              <th>Errors</th>
            </tr>
          </thead>
          <tbody>
            {preview.slice(0, 50).map((p, idx) => (
              <tr key={idx}>
                <td>{p.ok ? "✅" : "❌"}</td>
                <td>{p.draft.rigName}</td>
                <td>{p.draft.jobName}</td>
                <td>{p.draft.contractor}</td>
                <td>{p.draft.workOrder}</td>
                <td>{new Date(p.draft.startDate.toMillis()).toISOString().slice(0,10)}</td>
                <td>{new Date(p.draft.endDate.toMillis()).toISOString().slice(0,10)}</td>
                <td>{p.draft.duration}</td>
                <td className="small">{p.errors.join(", ")}</td>
              </tr>
            ))}
            {preview.length === 0 && (
              <tr>
                <td colSpan={9} className="small">Upload a file to preview.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {preview.length > 50 && (
        <div className="small" style={{ marginTop: 10 }}>
          Showing first 50 rows for preview. Import will include all valid rows.
        </div>
      )}
    </div>
  );
}
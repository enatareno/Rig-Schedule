import React, { useEffect, useMemo, useState } from "react";
import { collection, onSnapshot, orderBy, query } from "firebase/firestore";
import { db } from "./firebase";
import { Filters, Job, JobStatus } from "./types";
import FiltersBar from "./components/FiltersBar";
import JobsTable from "./components/JobsTable";
import JobDrawer from "./components/JobDrawer";
import ImportExcel from "./components/ImportExcel";
import Tabs, { TabKey } from "./components/Tabs";
import { computeConflicts } from "./utils/overlap";

const DEFAULT_FILTERS: Filters = {
  rigs: [],
  statuses: [],
  contractor: "",
  engineer: "",
  search: ""
};

function includesCI(hay: string, needle: string) {
  return hay.toLowerCase().includes(needle.toLowerCase());
}

export default function App() {
  const [tab, setTab] = useState<TabKey>("schedule");
  const [jobs, setJobs] = useState<Job[]>([]);
  const [filters, setFilters] = useState<Filters>(DEFAULT_FILTERS);
  const [openJob, setOpenJob] = useState<Job | null>(null);

  useEffect(() => {
    const q = query(collection(db, "jobs"), orderBy("startDate", "asc"));
    const unsub = onSnapshot(q, (snap) => {
      const rows = snap.docs.map(d => ({ id: d.id, ...(d.data() as any) })) as Job[];
      setJobs(rows);
    });
    return () => unsub();
  }, []);

  const filtered = useMemo(() => {
    const f = filters;

    return jobs.filter(j => {
      if (f.rigs.length && !f.rigs.includes(j.rigId)) return false;
      if (f.statuses.length && !f.statuses.includes(j.status as JobStatus)) return false;
      if (f.contractor && j.contractor !== f.contractor) return false;
      if (f.engineer && j.engineer !== f.engineer) return false;

      if (f.from && j.startDate?.toMillis() < f.from.getTime()) return false;
      if (f.to && j.startDate?.toMillis() > (f.to.getTime() + 86400000)) return false; // inclusive end

      if (f.search) {
        const s = f.search.trim();
        const blob = [
          j.jobName,
          j.workOrder,
          j.contractor,
          j.engineer,
          j.notes,
          j.locationText
        ].filter(Boolean).join(" • ");
        if (!includesCI(blob, s)) return false;
      }

      return true;
    });
  }, [jobs, filters]);

  const conflicts = useMemo(() => computeConflicts(filtered), [filtered]);

  const kpi = useMemo(() => {
    const total = filtered.length;
    const byStatus: Record<string, number> = {};
    for (const j of filtered) {
      byStatus[j.status] = (byStatus[j.status] || 0) + 1;
    }
    return { total, byStatus };
  }, [filtered]);

  return (
    <div className="container">
      <div className="header">
        <div>
          <div className="h1">Rig Schedule (Internal)</div>
          <div className="small">Multi-rig scheduling dashboard • Firestore-backed • Click rows to edit</div>
        </div>
        <Tabs active={tab} onChange={setTab} />
      </div>

      {tab === "schedule" && (
        <>
          <div className="kpi" style={{ marginBottom: 12 }}>
            <span className="pill">Jobs: {kpi.total}</span>
            {Object.entries(kpi.byStatus).map(([s, n]) => (
              <span key={s} className="pill">{s}: {n}</span>
            ))}
            {conflicts.size > 0 && <span className="pill" style={{ color: "var(--bad)" }}>Conflicts: {conflicts.size}</span>}
          </div>

          <FiltersBar jobs={jobs} filters={filters} setFilters={setFilters} />
          <JobsTable jobs={filtered} conflicts={conflicts} onOpen={setOpenJob} />
          <JobDrawer job={openJob} onClose={() => setOpenJob(null)} />
        </>
      )}

      {tab === "import" && (
        <ImportExcel />
      )}
    </div>
  );
}
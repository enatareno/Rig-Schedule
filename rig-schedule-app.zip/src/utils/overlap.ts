import { Job } from "../types";

export function computeConflicts(jobs: Job[]): Set<string> {
  // Returns a set of job IDs that overlap with another job on the same rig
  const conflicts = new Set<string>();
  const byRig: Record<string, Job[]> = {};

  for (const j of jobs) {
    if (!byRig[j.rigId]) byRig[j.rigId] = [];
    byRig[j.rigId].push(j);
  }

  for (const rigId of Object.keys(byRig)) {
    const list = byRig[rigId]
      .filter(j => j.startDate && j.endDate)
      .sort((a, b) => a.startDate.toMillis() - b.startDate.toMillis());

    for (let i = 0; i < list.length; i++) {
      const a = list[i];
      for (let k = i + 1; k < list.length; k++) {
        const b = list[k];

        // If b starts after a ends, we can break (because sorted by start)
        if (b.startDate.toMillis() > a.endDate.toMillis()) break;

        // Overlap check
        const overlaps = a.startDate.toMillis() <= b.endDate.toMillis() &&
                         b.startDate.toMillis() <= a.endDate.toMillis();
        if (overlaps) {
          conflicts.add(a.id);
          conflicts.add(b.id);
        }
      }
    }
  }

  return conflicts;
}
export function normKey(key: string): string {
  return key
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/\./g, "")
    .replace(/\//g, " ")
    .replace(/\(|\)|\:|\-|\_/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function toRigId(rigName: string): string {
  // "Rig No. 1" -> "rig-1"
  const n = (rigName || "").toString().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  return n || "rig-unknown";
}

export function safeStr(v: unknown): string {
  if (v === null || v === undefined) return "";
  return String(v).trim();
}

export function safeNum(v: unknown): number | null {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(String(v).replace(/[^0-9.\-]/g, ""));
  return Number.isFinite(n) ? n : null;
}

export function parseDurationDays(v: unknown): number {
  const s = safeStr(v);
  if (!s) return 0;
  const n = Number(s.replace(/[^0-9]/g, ""));
  return Number.isFinite(n) ? n : 0;
}

export function maybeUrl(v: string): { text: string; link: string } {
  const s = safeStr(v);
  if (!s) return { text: "", link: "" };
  const isUrl = /^https?:\/\//i.test(s);
  return { text: isUrl ? "" : s, link: isUrl ? s : "" };
}